from enum import Enum


class routers(Enum):
    PRINCIPAL =  "/"
    ENCUENTRA_EL_NUMERO = "/Encuentra-el-numero"
    TRES_EN_RAYA = "/Tres-en-raya"
    PIEDRA_PAPEL_TIJERAS = "/Piedra-papel-tijeras-lagarto-spock"
    FQA = "/FQA"