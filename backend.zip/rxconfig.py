import reflex as rx

config = rx.Config(
    app_name="MiniGames",
)